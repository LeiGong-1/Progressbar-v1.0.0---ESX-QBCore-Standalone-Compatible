# Progressbar ESX / QBCore / Standalone 兼容版

这是基于 `qbcore-framework/progressbar` 改过的双框架兼容版，可用于：

- ESX / es_extended
- QBCore / qb-core
- Standalone 独立资源
- ox_inventory busy 状态
- 常见 `progressBars:startUI` 简单进度条调用

## 安装

1. 把文件夹放进 `resources`。
2. 推荐文件夹名保持为：`progressbar`。
3. 在 `server.cfg` 里放到其他脚本前面启动：

```cfg
ensure progressbar
```

如果你的旧脚本写的是 `exports['progressbar']`，资源文件夹就必须叫 `progressbar`。
如果你的旧脚本写的是 `exports['progressBars']`，可以把文件夹改名为 `progressBars`，本版 NUI 已经支持自动识别资源名。

## config.lua

```lua
Config.Framework = 'auto' -- auto / esx / qb / standalone
Config.RegisterFrameworkProgressbar = true
Config.InventoryBusyState = true
Config.CancelControl = 200 -- ESC
```

`auto` 会自动检测：

1. `es_extended`
2. `qb-core`
3. 都没有时按 standalone 运行

## 通用 Export

```lua
exports['progressbar']:Progress({
    name = 'random_task',
    duration = 5000,
    label = '正在处理...',
    useWhileDead = false,
    canCancel = true,
    controlDisables = {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = true,
    },
    animation = {
        animDict = 'mp_suicide',
        anim = 'pill',
        flags = 49,
    },
    prop = {},
    propTwo = {},
}, function(cancelled)
    if not cancelled then
        print('完成')
    else
        print('取消')
    end
end)
```

## QBCore 写法

本版支持 QBCore 常见签名：

```lua
exports['progressbar']:Progressbar('random_task', '正在处理...', 5000, false, true, {
    disableMovement = false,
    disableCarMovement = false,
    disableMouse = false,
    disableCombat = true,
}, {
    animDict = 'mp_suicide',
    anim = 'pill',
    flags = 49,
}, {}, {}, function()
    print('完成')
end, function()
    print('取消')
end)
```

如果 `Config.RegisterFrameworkProgressbar = true`，并且 QBCore 当前没有自己的 `QBCore.Functions.Progressbar`，本资源会自动补上桥接。

## ESX 写法

```lua
exports['progressbar']:Progressbar('正在处理...', 5000, {
    FreezePlayer = true,
    animation = {
        type = 'anim',
        dict = 'mp_suicide',
        lib = 'pill',
        flags = 49,
    },
    onFinish = function()
        print('完成')
    end,
    onCancel = function()
        print('取消')
    end,
})
```

场景动画示例：

```lua
exports['progressbar']:Progressbar('正在施工...', 5000, {
    FreezePlayer = true,
    animation = {
        type = 'scenario',
        scenario = 'WORLD_HUMAN_HAMMERING',
    },
})
```

如果 `Config.RegisterFrameworkProgressbar = true`，并且 ESX 当前没有自己的 `ESX.Progressbar`，本资源会自动补上桥接。

## progressBars 旧资源兼容

```lua
exports['progressbar']:startUI(5000, '正在处理...')
TriggerEvent('progressBars:startUI', 5000, '正在处理...')
```

## 可用事件

```lua
TriggerEvent('progressbar:client:progress', action, finish)
TriggerEvent('progressbar:client:ProgressWithStartEvent', action, start, finish)
TriggerEvent('progressbar:client:ProgressWithTickEvent', action, tick, finish)
TriggerEvent('progressbar:client:ProgressWithStartAndTick', action, start, tick, finish)
TriggerEvent('progressbar:client:cancel')
```

## 可用 Exports

```lua
exports['progressbar']:Progress(action, cb)
exports['progressbar']:Progressbar(...)
exports['progressbar']:StartProgress(action, onStart, onTick, onFinish)
exports['progressbar']:startUI(duration, label)
exports['progressbar']:StartUI(duration, label)
exports['progressbar']:Cancel()
exports['progressbar']:isDoingSomething()
exports['progressbar']:GetFramework()
```

## 本版修复/增强

- 修复 NUI 里写死 `https://progressbar/...` 的问题，资源改名也不会 NUI failed fetch。
- 支持 ESX / QBCore / Standalone 自动检测。
- 增加 ESX 风格 `Progressbar(label, duration, options)`。
- 保留 QBCore 风格 `Progressbar(name, label, duration, ...)`。
- 增加 `progressBars:startUI` 简单兼容。
- 避免无动画进度条结束时清空玩家任务。
- 增强 prop model 数字 hash / 字符串模型名兼容。
- 增加资源停止时自动清理动画、物件和 busy 状态。
