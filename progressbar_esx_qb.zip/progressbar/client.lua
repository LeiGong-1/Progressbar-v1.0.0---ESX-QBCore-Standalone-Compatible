local CurrentResource = GetCurrentResourceName()
local Framework = {
    name = 'standalone',
    object = nil,
}

local DefaultAction = {
    name = '',
    duration = 0,
    label = '',
    useWhileDead = false,
    canCancel = true,
    disarm = true,
    controlDisables = Config.DefaultControlDisables or {
        disableMovement = false,
        disableCarMovement = false,
        disableMouse = false,
        disableCombat = false,
    },
    animation = {
        animDict = nil,
        anim = nil,
        flags = 0,
        task = nil,
    },
    prop = {
        model = nil,
        bone = nil,
        coords = vector3(0.0, 0.0, 0.0),
        rotation = vector3(0.0, 0.0, 0.0),
    },
    propTwo = {
        model = nil,
        bone = nil,
        coords = vector3(0.0, 0.0, 0.0),
        rotation = vector3(0.0, 0.0, 0.0),
    },
}

local Action = DefaultAction
local isDoingAction = false
local wasCancelled = false
local propNet = nil
local propTwoNet = nil
local isAnim = false
local isProp = false
local isPropTwo = false
local activeActionId = 0

local controls = {
    disableMouse = { 1, 2, 106 },
    disableMovement = { 30, 31, 36, 21, 75 },
    disableCarMovement = { 63, 64, 71, 72 },
    disableCombat = { 24, 25, 37, 47, 58, 140, 141, 142, 143, 263, 264, 257 },
}

local function debugPrint(message)
    if Config.Debug then
        print(('[%s] %s'):format(CurrentResource, message))
    end
end

local function safeCall(cb, ...)
    if type(cb) ~= 'function' then return end

    local ok, err = pcall(cb, ...)
    if not ok then
        print(('[%s] Callback error: %s'):format(CurrentResource, err))
    end
end

local function setBusyState(state)
    if not Config.InventoryBusyState then return end
    if not LocalPlayer or not LocalPlayer.state then return end

    LocalPlayer.state:set('inv_busy', state, true)
end

local function vec(value)
    if value == nil then
        return vector3(0.0, 0.0, 0.0)
    end

    local valueType = type(value)
    if valueType == 'vector3' or valueType == 'vector4' then
        return vector3(value.x or 0.0, value.y or 0.0, value.z or 0.0)
    end

    if valueType == 'table' then
        return vector3(value.x or value[1] or 0.0, value.y or value[2] or 0.0, value.z or value[3] or 0.0)
    end

    return vector3(0.0, 0.0, 0.0)
end

local function deepCopy(source)
    if type(source) ~= 'table' then return source end

    local target = {}
    for key, value in pairs(source) do
        target[key] = deepCopy(value)
    end

    return target
end

local function mergeTable(defaults, data)
    local result = deepCopy(defaults)

    if type(data) ~= 'table' then
        return result
    end

    for key, value in pairs(data) do
        if type(value) == 'table' and type(result[key]) == 'table' then
            result[key] = mergeTable(result[key], value)
        else
            result[key] = value
        end
    end

    return result
end

local function normalizeAction(action)
    local normalized = mergeTable(DefaultAction, action or {})

    normalized.duration = tonumber(normalized.duration) or 0
    normalized.label = normalized.label or normalized.text or normalized.message or ''
    normalized.canCancel = normalized.canCancel ~= false
    normalized.useWhileDead = normalized.useWhileDead == true
    normalized.controlDisables = mergeTable(Config.DefaultControlDisables or DefaultAction.controlDisables, normalized.controlDisables or {})

    if normalized.prop then
        normalized.prop.coords = vec(normalized.prop.coords)
        normalized.prop.rotation = vec(normalized.prop.rotation)
    end

    if normalized.propTwo then
        normalized.propTwo.coords = vec(normalized.propTwo.coords)
        normalized.propTwo.rotation = vec(normalized.propTwo.rotation)
    end

    return normalized
end

local function loadAnimDict(dict)
    if not dict or dict == '' then return false end

    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(5)
    end

    return true
end

local function getModelHash(model)
    if not model then return nil end

    if type(model) == 'number' then
        return model
    end

    return joaat(model)
end

local function loadModel(model)
    local modelHash = getModelHash(model)
    if not modelHash then return nil end

    if not IsModelValid(modelHash) then
        print(('[%s] Invalid prop model: %s'):format(CurrentResource, tostring(model)))
        return nil
    end

    RequestModel(modelHash)
    while not HasModelLoaded(modelHash) do
        Wait(5)
    end

    return modelHash
end

local function createAndAttachProp(prop, ped)
    if not prop or not prop.model then return nil end

    local modelHash = loadModel(prop.model)
    if not modelHash then return nil end

    local coords = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, 0.0)
    local propEntity = CreateObject(modelHash, coords.x, coords.y, coords.z, true, true, true)

    if not DoesEntityExist(propEntity) then
        return nil
    end

    local netId = ObjToNet(propEntity)
    SetNetworkIdExistsOnAllMachines(netId, true)
    NetworkUseHighPrecisionBlending(netId, true)
    SetNetworkIdCanMigrate(netId, false)

    local boneIndex = GetPedBoneIndex(ped, prop.bone or 60309)
    local propCoords = vec(prop.coords)
    local propRotation = vec(prop.rotation)

    AttachEntityToEntity(
        propEntity,
        ped,
        boneIndex,
        propCoords.x,
        propCoords.y,
        propCoords.z,
        propRotation.x,
        propRotation.y,
        propRotation.z,
        true,
        true,
        false,
        true,
        0,
        true
    )

    SetModelAsNoLongerNeeded(modelHash)

    return netId
end

local function deleteNetObject(netId)
    if not netId then return end

    local object = NetToObj(netId)
    if object and DoesEntityExist(object) then
        DetachEntity(object, true, true)
        DeleteEntity(object)
    end
end

local function disableControls()
    CreateThread(function()
        while isDoingAction do
            for disableType, isEnabled in pairs(Action.controlDisables or {}) do
                if isEnabled and controls[disableType] then
                    for _, control in ipairs(controls[disableType]) do
                        DisableControlAction(0, control, true)
                    end
                end
            end

            if Action.controlDisables and Action.controlDisables.disableCombat then
                DisablePlayerFiring(PlayerId(), true)
            end

            Wait(0)
        end
    end)
end

local function hasAnimation(animation)
    return animation and (animation.task or (animation.animDict and animation.anim))
end

local function startActionEffects()
    local ped = PlayerPedId()

    if not isDoingAction then return end

    if not isAnim and hasAnimation(Action.animation) then
        if Action.animation.task then
            TaskStartScenarioInPlace(ped, Action.animation.task, 0, true)
        elseif Action.animation.animDict and Action.animation.anim and DoesEntityExist(ped) and not IsEntityDead(ped) then
            if loadAnimDict(Action.animation.animDict) then
                TaskPlayAnim(ped, Action.animation.animDict, Action.animation.anim, 3.0, 3.0, -1, Action.animation.flags or 1, 0, false, false, false)
            end
        end

        isAnim = true
    end

    if not isProp and Action.prop and Action.prop.model then
        propNet = createAndAttachProp(Action.prop, ped)
        isProp = propNet ~= nil
    end

    if not isPropTwo and Action.propTwo and Action.propTwo.model then
        propTwoNet = createAndAttachProp(Action.propTwo, ped)
        isPropTwo = propTwoNet ~= nil
    end

    disableControls()
end

local function cleanupAction(cancelled)
    local ped = PlayerPedId()

    if hasAnimation(Action.animation) then
        if Action.animation.task then
            ClearPedTasks(ped)
        elseif Action.animation.animDict and Action.animation.anim then
            StopAnimTask(ped, Action.animation.animDict, Action.animation.anim, 1.0)
            ClearPedSecondaryTask(ped)
            RemoveAnimDict(Action.animation.animDict)
        end
    end

    deleteNetObject(propNet)
    deleteNetObject(propTwoNet)

    propNet = nil
    propTwoNet = nil
    isDoingAction = false
    wasCancelled = cancelled == true
    isAnim = false
    isProp = false
    isPropTwo = false

    setBusyState(false)
end

local function cancelAction()
    if not isDoingAction then return end

    cleanupAction(true)
    SendNUIMessage({
        action = 'cancel',
        label = Config.CancelText or 'CANCELLED',
    })
end

local function StartProgress(action, onStart, onTick, onFinish)
    local playerPed = PlayerPedId()
    local isPlayerDead = IsEntityDead(playerPed)

    if isDoingAction then
        return false
    end

    action = normalizeAction(action)

    if action.duration <= 0 then
        safeCall(onStart)
        safeCall(onFinish, false)
        return true
    end

    if isPlayerDead and not action.useWhileDead then
        safeCall(onFinish, true)
        return false
    end

    activeActionId = activeActionId + 1
    local thisActionId = activeActionId

    isDoingAction = true
    wasCancelled = false
    Action = action
    setBusyState(true)

    SendNUIMessage({
        action = 'progress',
        duration = action.duration,
        label = action.label,
    })

    startActionEffects()

    CreateThread(function()
        safeCall(onStart)

        while isDoingAction and thisActionId == activeActionId do
            Wait(1)
            safeCall(onTick)

            if IsControlJustPressed(0, Config.CancelControl or 200) and action.canCancel then
                cancelAction()
                break
            end

            if IsEntityDead(playerPed) and not action.useWhileDead then
                cancelAction()
                break
            end
        end

        safeCall(onFinish, wasCancelled)
    end)

    return true
end

local function buildQBCoreAction(name, label, duration, useWhileDead, canCancel, disableControlsTable, animation, prop, propTwo)
    return {
        name = name,
        duration = duration,
        label = label,
        useWhileDead = useWhileDead,
        canCancel = canCancel,
        controlDisables = disableControlsTable,
        animation = animation,
        prop = prop,
        propTwo = propTwo,
    }
end

local function QBCoreProgressbar(name, label, duration, useWhileDead, canCancel, disableControlsTable, animation, prop, propTwo, onFinish, onCancel)
    local action = buildQBCoreAction(name, label, duration, useWhileDead, canCancel, disableControlsTable, animation, prop, propTwo)

    return StartProgress(action, nil, nil, function(cancelled)
        if cancelled then
            safeCall(onCancel)
        else
            safeCall(onFinish)
        end
    end)
end

local function buildESXAction(label, duration, options)
    options = options or {}

    local controlDisables = options.controlDisables or options.disableControls or {}
    local freezePlayer = options.FreezePlayer == true or options.freezePlayer == true or options.freeze == true

    if freezePlayer then
        controlDisables.disableMovement = true
        controlDisables.disableCarMovement = true
    end

    local animation = options.animation or options.Animation or {}
    local normalizedAnimation = {}

    if animation.type == 'anim' or animation.animDict or animation.dict then
        normalizedAnimation.animDict = animation.animDict or animation.dict
        normalizedAnimation.anim = animation.anim or animation.lib or animation.clip
        normalizedAnimation.flags = animation.flags or animation.flag or 49
    elseif animation.type == 'scenario' or animation.task or animation.scenario then
        normalizedAnimation.task = animation.task or animation.scenario or animation.dict
    end

    return {
        name = options.name or 'esx_progressbar',
        duration = duration,
        label = label,
        useWhileDead = options.useWhileDead == true,
        canCancel = options.canCancel ~= false,
        controlDisables = controlDisables,
        animation = normalizedAnimation,
        prop = options.prop or options.Prop or {},
        propTwo = options.propTwo or options.PropTwo or {},
    }, freezePlayer
end

local function ESXProgressbar(label, duration, options)
    local action, freezePlayer = buildESXAction(label, duration, options or {})
    local ped = PlayerPedId()

    local function start()
        if freezePlayer then
            FreezeEntityPosition(ped, true)
        end

        safeCall(options and (options.onStart or options.OnStart))
    end

    local function finish(cancelled)
        if freezePlayer then
            FreezeEntityPosition(ped, false)
        end

        if cancelled then
            safeCall(options and (options.onCancel or options.OnCancel))
        else
            safeCall(options and (options.onFinish or options.OnFinish))
        end
    end

    return StartProgress(action, start, nil, finish)
end

local function SimpleProgress(duration, label, cb)
    return StartProgress({
        name = 'simple_progressbar',
        duration = duration,
        label = label or '',
        useWhileDead = false,
        canCancel = true,
        controlDisables = {
            disableCombat = true,
        },
    }, nil, nil, cb)
end

local function CompatProgressbar(...)
    local args = { ... }

    if type(args[2]) == 'number' then
        return ESXProgressbar(args[1], args[2], args[3] or {})
    end

    return QBCoreProgressbar(args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9], args[10], args[11])
end

local function DetectFramework()
    local requested = Config.Framework or 'auto'

    if requested == 'standalone' then
        Framework.name = 'standalone'
        Framework.object = nil
        return Framework
    end

    if (requested == 'auto' or requested == 'esx') and GetResourceState('es_extended') == 'started' then
        local ok, esx = pcall(function()
            return exports['es_extended']:getSharedObject()
        end)

        if ok and esx then
            Framework.name = 'esx'
            Framework.object = esx
            return Framework
        end
    end

    if (requested == 'auto' or requested == 'qb') and GetResourceState('qb-core') == 'started' then
        local ok, qb = pcall(function()
            return exports['qb-core']:GetCoreObject()
        end)

        if ok and qb then
            Framework.name = 'qb'
            Framework.object = qb
            return Framework
        end
    end

    Framework.name = 'standalone'
    Framework.object = nil
    return Framework
end

local function RegisterFrameworkProgressbar()
    if not Config.RegisterFrameworkProgressbar then return end

    DetectFramework()

    if Framework.name == 'qb' and Framework.object and Framework.object.Functions then
        if not Framework.object.Functions.Progressbar then
            Framework.object.Functions.Progressbar = QBCoreProgressbar
            debugPrint('Registered QBCore.Functions.Progressbar bridge')
        end
    elseif Framework.name == 'esx' and Framework.object then
        if not Framework.object.Progressbar then
            Framework.object.Progressbar = ESXProgressbar
            debugPrint('Registered ESX.Progressbar bridge')
        end
    end
end

CreateThread(function()
    for _ = 1, 30 do
        RegisterFrameworkProgressbar()
        if Framework.name ~= 'standalone' then break end
        Wait(500)
    end
end)

RegisterNetEvent('progressbar:client:ToggleBusyness', function(bool)
    isDoingAction = bool == true
end)

RegisterNetEvent('progressbar:client:progress', function(action, finish)
    StartProgress(action, nil, nil, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithStartEvent', function(action, start, finish)
    StartProgress(action, start, nil, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithTickEvent', function(action, tick, finish)
    StartProgress(action, nil, tick, finish)
end)

RegisterNetEvent('progressbar:client:ProgressWithStartAndTick', function(action, start, tick, finish)
    StartProgress(action, start, tick, finish)
end)

RegisterNetEvent('progressbar:client:cancel', cancelAction)
RegisterNetEvent('progressbar:client:Cancel', cancelAction)
RegisterNetEvent('progressbar:cancel', cancelAction)

RegisterNetEvent('progressbar:client:Progressbar', function(...)
    CompatProgressbar(...)
end)

RegisterNetEvent('progressBars:startUI', function(duration, label)
    SimpleProgress(duration, label)
end)

RegisterNetEvent('progressBars:client:startUI', function(duration, label)
    SimpleProgress(duration, label)
end)

RegisterNetEvent('esx_progressbar:progressbar', function(label, duration, options)
    ESXProgressbar(label, duration, options or {})
end)

RegisterNUICallback('FinishAction', function(_, cb)
    if isDoingAction then
        cleanupAction(false)
    end

    cb('ok')
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= CurrentResource then return end
    if isDoingAction then
        cleanupAction(true)
    end
end)

exports('Progress', function(action, finish)
    return StartProgress(action, nil, nil, finish)
end)

exports('ProgressWithStartEvent', function(action, start, finish)
    return StartProgress(action, start, nil, finish)
end)

exports('ProgressWithTickEvent', function(action, tick, finish)
    return StartProgress(action, nil, tick, finish)
end)

exports('ProgressWithStartAndTick', function(action, start, tick, finish)
    return StartProgress(action, start, tick, finish)
end)

exports('Progressbar', CompatProgressbar)
exports('progressbar', CompatProgressbar)
exports('StartProgress', StartProgress)
exports('Start', SimpleProgress)
exports('StartUI', SimpleProgress)
exports('startUI', SimpleProgress)
exports('Cancel', cancelAction)
exports('isDoingSomething', function()
    return isDoingAction
end)

exports('GetFramework', function()
    return Framework.name
end)
