Config = Config or {}

-- auto / esx / qb / standalone
-- auto 会优先检测 es_extended，其次 qb-core；没有核心时按 standalone 运行。
Config.Framework = 'auto'

-- 是否尝试把进度条函数注册进 ESX/QBCore 核心对象。
-- 不会强制覆盖核心里已经存在的 Progressbar 函数。
Config.RegisterFrameworkProgressbar = true

-- ox_inventory / 常见背包 busy 状态。ESX/QBCore/Standalone 都可以保留。
Config.InventoryBusyState = true

-- 默认取消键：200 = ESC / Pause Menu
Config.CancelControl = 200

-- UI 取消时显示文本
Config.CancelText = '已取消'

-- 默认控制禁用项
Config.DefaultControlDisables = {
    disableMovement = false,
    disableCarMovement = false,
    disableMouse = false,
    disableCombat = false,
}
