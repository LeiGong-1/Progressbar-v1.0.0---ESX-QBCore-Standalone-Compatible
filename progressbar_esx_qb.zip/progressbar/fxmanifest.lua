fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'leigong'
description 'Progressbar compatible with ESX, QBCore and Standalone resources.'
version '1.1.0-esx-qb'

ui_page 'html/index.html'

shared_script 'config.lua'
client_script 'client.lua'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
