document.addEventListener("DOMContentLoaded", () => {
    const resourceName = typeof GetParentResourceName === "function" ? GetParentResourceName() : "progressbar";

    const ProgressBar = {
        init() {
            this.progressLabel = document.getElementById("progress-label");
            this.progressPercentage = document.getElementById("progress-percentage");
            this.progressBar = document.getElementById("progress-bar");
            this.progressContainer = document.querySelector(".progress-container");
            this.animationFrameRequest = null;
            this.cancelledTimer = null;
            this.setupListeners();
        },

        setupListeners() {
            window.addEventListener("message", (event) => {
                const data = event.data || {};

                if (data.action === "progress") {
                    this.update(data);
                } else if (data.action === "cancel") {
                    this.cancel(data.label || "已取消");
                }
            });
        },

        update(data) {
            if (this.animationFrameRequest) {
                cancelAnimationFrame(this.animationFrameRequest);
            }

            clearTimeout(this.cancelledTimer);

            const duration = Math.max(parseInt(data.duration, 10) || 0, 1);
            const startTime = Date.now();

            this.progressLabel.textContent = data.label || "";
            this.progressPercentage.textContent = "0%";
            this.progressBar.style.width = "0%";
            this.progressContainer.style.display = "block";

            const animateProgress = () => {
                const timeElapsed = Date.now() - startTime;
                const progress = Math.min(timeElapsed / duration, 1);
                const percentage = Math.round(progress * 100);

                this.progressBar.style.width = `${percentage}%`;
                this.progressPercentage.textContent = `${percentage}%`;

                if (progress < 1) {
                    this.animationFrameRequest = requestAnimationFrame(animateProgress);
                } else {
                    this.onComplete();
                }
            };

            this.animationFrameRequest = requestAnimationFrame(animateProgress);
        },

        cancel(label) {
            if (this.animationFrameRequest) {
                cancelAnimationFrame(this.animationFrameRequest);
                this.animationFrameRequest = null;
            }

            this.progressLabel.textContent = label;
            this.progressPercentage.textContent = "";
            this.progressBar.style.width = "100%";
            this.cancelledTimer = setTimeout(() => this.onCancel(), 700);
        },

        onComplete() {
            this.reset();
            this.postAction("FinishAction");
        },

        onCancel() {
            this.reset();
        },

        reset() {
            this.progressContainer.style.display = "none";
            this.progressBar.style.width = "0%";
            this.progressPercentage.textContent = "";
        },

        postAction(action) {
            fetch(`https://${resourceName}/${action}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({}),
            }).catch(() => {});
        },
    };

    ProgressBar.init();
});
